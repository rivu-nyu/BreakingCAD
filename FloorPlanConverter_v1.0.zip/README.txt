# FloorPlan Converter - Standalone Executable

## How to Use:
1. Double-click `FloorPlanConverter.exe` OR
2. Run `launch_converter.bat`

## First Launch:
- The application will open in your default web browser
- If it doesn't open automatically, go to: http://localhost:7860
- The first launch may take longer as it initializes all models

## Features:
- Convert hand-drawn sketches to DXF files
- Convert PNG floorplan images to DXF files
- Adjustable scale and wall parameters
- No internet connection required
- Self-contained application

## Troubleshooting:
- If the app doesn't start, try running as administrator
- Make sure no firewall is blocking the application
- Check that all DLL files are in the same folder as the executable

## Output Files:
- DXF files are saved in the `outputs` folder
- The folder will be created automatically when you first process an image

Enjoy using FloorPlan Converter!
